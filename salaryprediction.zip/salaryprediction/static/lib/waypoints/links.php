<?php
  $links = array(
    'js' => '../static/lib/waypoints/waypoints.min.js'
  );
?>
