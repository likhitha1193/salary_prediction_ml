#1.importing libraries
from flask import Flask,render_template,request,redirect,url_for,flash #render_template: to display any webpage
#2.creating the object of Flask class
app=Flask(__name__)

#loading the models 
import pickle
with open('models/salary_rf_model.pkl','rb')as f:
    rf_model=pickle.load(f)

#loading the label encoders
with open("models/lb_job_title.pkl", "rb") as f:
    lb_job = pickle.load(f)

job_titles = lb_job.classes_.tolist()

# User-defined Function for Prediction
def predict_salary(age=34.0,gender='Male',education='PhD',job_title='Software Engineer',experience=5.0):
    lst=[]
    #age
    lst=lst+[age]
    
    #gender
    if gender=='Female':
        lst=lst+[0]
    elif gender=='Male':
        lst=lst+[1]
    elif gender=='Other':
        lst=lst+[2]

    #education
    if education=="Bachelor's Degree":
        lst=lst+[0]
    elif education=='High School':
        lst=lst+[1]
    elif education=="Master's Degree":
        lst=lst+[2]
    elif education=="PhD":
        lst=lst+[3]
    
    #job title
    if job_title in lb_job.classes_:
        job_encoded = lb_job.transform([job_title])[0]
    else:
        raise ValueError(f"Unknown job title: {job_title}")
    lst.append(job_encoded)
    
    job_encoded = lb_job.transform([job_title])
    lst.extend(job_encoded)
    
    #experience
    lst=lst+[experience]

    print(lst)
    result=rf_model.predict([lst])
    return result[0]

#3.creating the route

# index
@app.route("/")  #@app.route("/",methods=['GET','POST']) #By default it takes 'GET'
def index():
    return render_template("index.html", job_titles=job_titles)

# about
@app.route("/about")  #@app.route("/",methods=['GET','POST']) #By default it takes 'GET'
def about():
    return render_template("about.html")

@app.route("/predict",methods=['POST'])
def predict():
    if request.method=='POST':
        age = request.form.get('Age')
        gender = request.form.get('Gender')
        education_level = request.form.get('Education Level', '').strip()
        job_title = request.form.get('job_title', '').strip()
        experience = request.form.get('Years of Experience')

        if not job_title or job_title not in lb_job.classes_:
            return "Invalid job title. Please select from the dropdown.", 400
        
        result=predict_salary(age,gender,education_level,job_title,experience)
        return render_template('index.html',prediction=result)
    return "Prediction"

if __name__=="__main__":
    app.run(debug=True,port=4500)